# p2pFileSharingApp

Simple p2pFileSharingApplication
1.Run Content_Discovery.py
2.Announce your chunks using Announcer.py
3.Open Server.py
4.Run your Downloader.py, then choose a file from your Content_Discovery to download.
